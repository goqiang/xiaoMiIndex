var reSpans=document.querySelectorAll("a");
			var lis=document.querySelectorAll("ul li");
			var ul=document.querySelector("ul");
			var lisx=document.querySelectorAll("ol li");
			var i=0;			
			//左
			reSpans[0].onclick=function (){
				(i>0)?i--:null;
				ul.style.left= -i*300 +"px";
				init(i);
			}
			//右
			reSpans[1].onclick=function (){
				(i<lis.length-1)?i++:null;
				ul.style.left= -i*300 +"px";
				init(i);
			}
			!function () {
				for(var k=0;k<lisx.length;k++)
				{
					lisx[k].index=k;
					lisx[k].onclick=function(){
						i=this.index;
						ul.style.left= -i*300 +"px";
						init(i);
					}
				}
			}()
			
			function init(i) {
				for(var j=0;j<lisx.length;j++)
				{
				   lisx[j].className="";	
				}
				lisx[i].className="nowx";	
			}  